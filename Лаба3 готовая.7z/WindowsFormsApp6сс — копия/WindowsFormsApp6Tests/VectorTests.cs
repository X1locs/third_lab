﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WindowsFormsApp6;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6.Tests
{
    [TestClass()]
    public class VectorTests
    {
        //должен вывести координату x
        [TestMethod()]
        public void Verbose5Test()
        {
           var vector = new Vector(10, 2, 3);
           Assert.AreEqual("10", vector.Verbose5());
        }

        //должен вывести координату y
        [TestMethod()]
        public void Verbose6Test()
        {
            var vector = new Vector(10, 2, 3);
            Assert.AreEqual("2", vector.Verbose6());
        }

        //должен вывести координату z
        [TestMethod()]
        public void Verbose7Test()
        {
            var vector = new Vector(10, 2, 3);
            Assert.AreEqual("3", vector.Verbose7());
        }

        //должен вывести сумму координат (x;y;z)
        [TestMethod()]
        public void Verbose3Test()
        {
            var vector = new Vector(10, 2, 2);
            Assert.AreEqual("14", vector.Verbose2());
        }

        //выводит сумму 
        [TestMethod()]
        public void AddNumberTest()
        {
            var A = new Vector(10, 2, 1);
            var B = new Vector(7, 1, 3);
            var vector = A + B;
            Assert.AreEqual("17,3,4", vector.Verbose());
        }

        //выводит разность
        [TestMethod()]
        public void SubNumberTest()
        {
            var A = new Vector(10, 2, 1);
            var B = new Vector(7, 1, 2);
            var vector = A - B;
            Assert.AreEqual("3,1,-1", vector.Verbose());
        }
        
        //выводит скалярное произведение
        [TestMethod()]
        public void MulByNumberTest()
        {
            var A = new Vector(10, 2, 3);
            var B = new Vector(7, 1, 8);
            var vector = A * B;
            Assert.AreEqual("96", vector.Verbose2());
        }

        //выводит длину вектора
        [TestMethod()]
        public void LenghtNumberTest()
        {
            var A = new Vector(4, 3, 0);
            var vector = A;
            Assert.AreEqual("5", vector.Verbose4());
        }

        //векторное произведение 
        [TestMethod()]
        public void UmNumberTest()
        {
            var A = new Vector(2, 3, 5);
            var B = new Vector(-7, 3, 0);

            var ax = (3 * 0 - 3 * 5);
            var ay = (2 * 0 - 5 * (-7));
            var az = (2 * 3 - (-7) * 3);
            var C = new Vector(ax, -ay, az);
            var vector = C;
            Assert.AreEqual("-15,-35,27", vector.Verbose());
        }

    }
}