﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate()
        {
            try
            {
                var ax = double.Parse(textBox1.Text);
                var ay = double.Parse(textBox2.Text);
                var az = double.Parse(textBox3.Text);
                var bx = double.Parse(textBox4.Text);
                var by = double.Parse(textBox5.Text);
                var bz = double.Parse(textBox6.Text);                                             

                var resultVector = new Vector (0,0,0);           
 
                switch (comboBox1.Text)
                {
                    case "+":
                        // если плюсик выбрали, то складываем
                        var first = ax + bx;
                        var second = ay + by;
                        var third = az + bz;

                        var sumVector = new Vector(first, second, third);

                        resultVector = sumVector;
                        break;
                    case "-":
                        // если минус, то вычитаем
                        var firstA = ax - bx;
                        var secondA = ay - by;
                        var thirdA = az - bz;

                        var minusVector = new Vector(firstA, secondA, thirdA);
                        resultVector = minusVector;
                        break;
                    case "*":
                        // если *, то вычисляем векторное произведение
                        var first_A = ay * bz - by * az;
                        var second_A = ax * bz - bx * az;
                        var third_A = ax * by - bx * ay;

                        var mulVector = new Vector(first_A, -second_A, third_A);
                        resultVector = mulVector;
                        break;
                    case "/":
                        // если /, то вычисляем скалярное произведение
                        var first1 = ax * bx;
                        var second1 = ay * by;
                        var third1 = az * bz;

                        var ff = first1 + second1 + third1;                        

                        string gg = Convert.ToString(ff);

                        MessageBox.Show("Скалярное произведение векторов А и В: " + gg);
                        break;

                    case "--":
                        //если --, то вычисляем длину вектора
                        var first_1 = ax * ax;
                        var second_1 = ay * ay;
                        var third_1 = az * az;

                        var first_2 = bx * bx;
                        var second_2 = by * by;
                        var third_2 = bz * bz;

                        var lenghtA = Math.Sqrt(Math.Abs(first_1 + second_1 + third_1));
                        var lenghtB = Math.Sqrt(Math.Abs(first_2 + second_2 + third_2));

                        string astralis = Convert.ToString(lenghtA);
                        string faze = Convert.ToString(lenghtB);

                        MessageBox.Show("Длина вектора А: " + astralis + "\n"
                            + "Длина вектора В: " + faze);

                        break;
                    default:
                        // а если что-то другое, то просто 0 выводим,
                        // такое маловероятно, но надо указать иначе не скомпилируется
                        sumVector = new Vector(0, 0, 0);
                        minusVector = new Vector(0, 0, 0);
                        break;
                }
                             
                textBox7.Text = resultVector.Verbose5();
                textBox8.Text = resultVector.Verbose6();
                textBox9.Text = resultVector.Verbose7();             
            }
            catch (FormatException)
            {
                // если тип преобразовать не смогли             
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Calculate();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {        
            Calculate();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Calculate();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            Calculate();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            Calculate();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            Calculate();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            Calculate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("9) Вектор \n" +
                "- сложение \n" +
                "- вычитание векторов \n" +
                "- вычисление скалярного произведения двух векторов \n" +
                "- длина вектора \n" +
                "- векторное произведение");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("+ сложение \n" +
                "- вычитание \n" +
                "* векторное произведение \n" +
                "/ скалярное произведение \n" +
                "-- длина вектора");
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox2.Focus();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox3.Focus();
            }
        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox4.Focus();
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox5.Focus();
            }
        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBox6.Focus();
            }
        }

        private void textBox6_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (e.KeyChar == (char)Keys.Space);
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8) //Если символ, введенный с клавы - не цифра (IsDigit),
            {
                e.Handled = true;// то событие не обрабатывается. ch!=8 (8 - это Backspace)
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (e.KeyChar == (char)Keys.Space);
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8) //Если символ, введенный с клавы - не цифра (IsDigit),
            {
                e.Handled = true;// то событие не обрабатывается. ch!=8 (8 - это Backspace)
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (e.KeyChar == (char)Keys.Space);
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8) //Если символ, введенный с клавы - не цифра (IsDigit),
            {
                e.Handled = true;// то событие не обрабатывается. ch!=8 (8 - это Backspace)
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (e.KeyChar == (char)Keys.Space);
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8) //Если символ, введенный с клавы - не цифра (IsDigit),
            {
                e.Handled = true;// то событие не обрабатывается. ch!=8 (8 - это Backspace)
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (e.KeyChar == (char)Keys.Space);
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8) //Если символ, введенный с клавы - не цифра (IsDigit),
            {
                e.Handled = true;// то событие не обрабатывается. ch!=8 (8 - это Backspace)
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (e.KeyChar == (char)Keys.Space);
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8) //Если символ, введенный с клавы - не цифра (IsDigit),
            {
                e.Handled = true;// то событие не обрабатывается. ch!=8 (8 - это Backspace)
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
        }
    }
}