﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6
{
    public class Vector
    {
        private double x, y, k, z;

        public Vector(double k)
        {
            this.k = k;
        }

        public Vector(double x, double y, double z)
        {     
            this.x = x;
            this.y = y;
            this.z = z;
        }

        //должен вывести координаты вектора (x,y,z).
        public string Verbose()
        {
            return String.Format("{0},{1},{2}", this.x, this.y, this.z);
        }

        //сумма координат
        public string Verbose2()
        {
            var A = new Vector(this.x, this.y, this.z);
            var result = A.x + A.y + A.z;
            return String.Format("{0}", result);
        }

        //длина
        public string Verbose4()
        {
            var result = Math.Sqrt(Math.Abs(this.x * this.x + this.y * this.y + this.z * this.z));
            return String.Format("{0}", result);
        }

        //координата x
        public string Verbose5()
        {
            var A = new Vector(this.x, this.y, this.z);
            var result = A.x;
            return String.Format("{0}", result);
        }

        //координата y
        public string Verbose6()
        {
            var A = new Vector(this.x, this.y, this.z);
            var result = A.y;
            return String.Format("{0}", result);
        }

        //координата z
        public string Verbose7()
        {
            var A = new Vector(this.x, this.y, this.z);
            var result = A.z;
            return String.Format("{0}", result);
        }

        //сложение
        public static Vector operator +(Vector A, Vector B)
        {
            return new Vector(A.x + B.x, A.y + B.y, A.z + B.z);
        }

        //вычитание
        public static Vector operator -(Vector A, Vector B)
        {
            return new Vector(A.x - B.x, A.y - B.y, A.z - B.z);
        }

        //скалярное произведение
        public static Vector operator *(Vector A, Vector B)
        {
            return new Vector(A.x * B.x, A.y * B.y, A.z * B.z);
        }

        //Длина вектора
        public static Vector operator --(Vector A)
        {
            return new Vector(Math.Sqrt(Math.Abs(A.x * A.x + A.y * A.y + A.z * A.z)));
        }

        //векторное произведение 
        public static Vector operator /(Vector A, Vector B)
        {
            var ax = (A.y * B.z - B.y * A.z);
            var ay = (A.x * B.z - B.x * A.z);
            var az = (A.x * B.y - B.x * A.y);
            return new Vector(ax, az, ay);
        }

    }
}
