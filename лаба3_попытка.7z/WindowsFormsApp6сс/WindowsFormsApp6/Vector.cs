﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6
{
    public class Vector
    {
        private double x, y, k, alpha;       

        public Vector(double k)
        {
            this.k = k;
        }

        public Vector(double x, double y)
        {     
            this.x = x;
            this.y = y;
        }
        //должен вывести координаты вектора (x,y).
        public string Verbose()
        {
            return String.Format("{0},{1}", this.x, this.y);
        }

        public string Verbose2()
        {
            var result = this.x + this.y;
            return String.Format("{0}", result);
        }

        public string Verbose3()
        {
            var result = (Math.Sqrt(Math.Abs(this.x * this.x + this.y * this.y)));
            return String.Format("{0}", result);
        }

        public string Verbose4()
        {
            var A = new Vector(this.x, this.y);
            var B = new Vector(this.x, this.y);
            var result = (Math.Sqrt(Math.Abs(A.x * A.x + A.y * A.y)) * Math.Sqrt(Math.Abs(B.x * B.x + B.y * B.y)) * ((Math.Sin(alpha) * Math.PI) / 180));
            return String.Format("{0}", result);
        }

        public static Vector operator +(Vector A, Vector B)
        {
            return new Vector(A.x + B.x, A.y + B.y);
        }

        public static Vector operator -(Vector A, Vector B)
        {
            return new Vector(A.x - B.x, A.y - B.y);
        }

        public static Vector operator *(Vector A, Vector B)
        {
            return new Vector(A.x * B.x, A.y * B.y);
        }

        public static Vector operator +(Vector A)
        {
            return new Vector(Math.Sqrt(Math.Abs(A.x * A.x + A.y * A.y)));
        }

        public static Vector operator *(Vector A,Vector B, double alpha)
        {                      
            return new Vector(Math.Sqrt(Math.Abs(A.x * A.x + A.y * A.y)) * Math.Sqrt(Math.Abs(B.x * B.x + B.y * B.y)) * ((Math.Sin(alpha)*Math.PI)/180));
        }

    }
}
