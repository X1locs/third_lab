﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WindowsFormsApp6;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp6.Tests
{
    [TestClass()]
    public class VectorTests
    {
        [TestMethod()]
        public void VerboseTest()
        {
           var vector = new Vector(10, 2);
           Assert.AreEqual("10,2", vector.Verbose());
        }

        [TestMethod()]
        public void Verbose2Test()
        {
            var vector = new Vector(10, 2);
            Assert.AreEqual("12", vector.Verbose2());
        }

        [TestMethod()]
        public void Verbose3Test()
        {
            var vector = new Vector(3, 4);
            Assert.AreEqual("5", vector.Verbose3());
        }

        [TestMethod()]
        public void AddNumberTest()
        {
            var A = new Vector(10,2);
            var B = new Vector(7, 1);
            var vector = A + B;
            Assert.AreEqual("17,3", vector.Verbose());
        }

        [TestMethod()]
        public void SubNumberTest()
        {
            var A = new Vector(10, 2);
            var B = new Vector(7, 1);
            var vector = A - B;
            Assert.AreEqual("3,1", vector.Verbose());
        }

        [TestMethod()]
        public void MulByNumberTest()
        {
            var A = new Vector(10, 2);
            var B = new Vector(7, 1);
            var vector = A * B;
            Assert.AreEqual("72", vector.Verbose2());
        }

        [TestMethod()]
        public void LenghtNumberTest()
        {
            var A = new Vector(3, 4);       
            var vector = A;
            Assert.AreEqual("5", vector.Verbose3());
        }
      
    }
}